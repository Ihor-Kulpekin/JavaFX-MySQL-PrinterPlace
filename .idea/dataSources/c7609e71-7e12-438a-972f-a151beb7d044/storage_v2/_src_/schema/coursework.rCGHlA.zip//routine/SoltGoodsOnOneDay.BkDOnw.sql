create
  definer = root@localhost procedure SoltGoodsOnOneDay()
BEGIN
Select nameservice.Kind_Service,ordering.Date_Ordering,sum(ordering.Number_Service) from
nameservice Inner Join ordering 
On nameservice.Kind_Service = ordering.Kind_Service
where((ordering.Date_Ordering)='20-11-1999')
Group By(nameservice.Name_Service) desc
Having(count(ordering.Number_Service));
END;

