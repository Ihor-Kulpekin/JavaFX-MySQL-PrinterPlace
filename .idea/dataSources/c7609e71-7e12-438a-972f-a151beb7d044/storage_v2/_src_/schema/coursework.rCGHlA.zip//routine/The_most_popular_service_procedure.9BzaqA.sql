create
  definer = root@localhost procedure The_most_popular_service_procedure()
BEGIN
Select nameservice.Kind_Service,sum(ordering.Number_Service) from
nameservice Inner Join ordering 
On nameservice.Kind_Service = ordering.Kind_Service
Group By(ordering.Kind_Service)desc
Having(sum(ordering.Number_Service)) ;
END;

