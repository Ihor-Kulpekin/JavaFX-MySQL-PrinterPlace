create
  definer = root@localhost procedure soltGoodinAllTime()
BEGIN
Select  nameservice.Kind_Service, 
sum(ordering.Number_Service),sum(ordering.General_Price),
count(ordering.id_ordering) from nameservice Inner Join ordering On
nameservice.Kind_Service = ordering.Kind_service
where(nameservice.Kind_Service = 'Flaera А4')
Group By(nameservice.Kind_Service);
END;

