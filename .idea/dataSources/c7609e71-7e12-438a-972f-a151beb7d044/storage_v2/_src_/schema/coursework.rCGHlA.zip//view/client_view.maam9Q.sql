create view client_view as
select `coursework`.`client`.`id_Client`        AS `id_Client`,
       `coursework`.`client`.`Name_Client`      AS `Name_Client`,
       `coursework`.`client`.`Last_Name_Client` AS `Last_Name_Client`,
       `coursework`.`client`.`Code_Client`      AS `Code_Client`,
       `coursework`.`client`.`Mobile_Number`    AS `Mobile_Number`,
       `coursework`.`client`.`Email`            AS `Email`
from `coursework`.`client`;

