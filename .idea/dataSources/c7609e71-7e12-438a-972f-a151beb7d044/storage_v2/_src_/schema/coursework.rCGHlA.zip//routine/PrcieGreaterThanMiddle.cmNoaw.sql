create
  definer = root@localhost procedure PrcieGreaterThanMiddle()
BEGIN
Select nameservice.Kind_Service,service.Name, nameservice.Price from service
Inner Join nameservice On   nameservice.Name_Service = service.Name
where((nameservice.Price)>
(select avg(nameservice.Price) from nameservice Inner Join service On
nameservice.id_Name_Service = service.id_service))
Group By(nameservice.Kind_Service)
Having((service.Name)='Bukletu') ;
END;

