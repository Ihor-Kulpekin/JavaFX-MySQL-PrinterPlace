create view service_view as
select `coursework`.`service`.`id_service` AS `id_service`, `coursework`.`service`.`Name` AS `Name`
from `coursework`.`service`;

