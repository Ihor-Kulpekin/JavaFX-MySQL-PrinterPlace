create
  definer = root@localhost procedure AverageSellGood()
BEGIN
Select nameservice.Kind_Service, avg(ordering.Number_Service),
count(ordering.id_ordering)
from nameservice Inner Join ordering On 
nameservice.Kind_Service = ordering.Kind_Service
where(nameservice.Kind_Service = 'Bukletu A4');
END;

