create view nameservice_view as
select `coursework`.`nameservice`.`id_Name_Service` AS `id_Name_Service`,
       `coursework`.`nameservice`.`Name_Service`    AS `Name_Service`,
       `coursework`.`nameservice`.`Kind_Service`    AS `Kind_Service`,
       `coursework`.`nameservice`.`Price`           AS `Price`
from `coursework`.`nameservice`;

