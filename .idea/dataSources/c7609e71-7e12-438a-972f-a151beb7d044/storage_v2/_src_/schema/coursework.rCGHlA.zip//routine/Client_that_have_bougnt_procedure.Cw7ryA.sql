create
  definer = root@localhost procedure Client_that_have_bougnt_procedure()
BEGIN
Select client.Name_Client,client.Last_Name_Client, 
nameservice.Kind_Service,count(ordering.id_ordering),sum(ordering.General_Price) from 
nameservice Inner Join(client Inner Join ordering 
On client.id_Client = ordering.Client_id) On
nameservice.Kind_Service = ordering.Kind_Service
where((nameservice.Kind_Service)='Bukletu A4');END;

