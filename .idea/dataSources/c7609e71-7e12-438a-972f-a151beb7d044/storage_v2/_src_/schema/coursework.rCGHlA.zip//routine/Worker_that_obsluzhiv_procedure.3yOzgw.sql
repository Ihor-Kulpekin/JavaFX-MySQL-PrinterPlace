create
  definer = root@localhost procedure `Worker_that obsluzhiv_procedure`()
BEGIN
Select  worker.Name_Worker, worker.Last_Name_Worker,
count(worker.id_worker),sum(ordering.General_Price) from
worker Inner join ordering On
worker.id_worker = ordering.Worker_id
where((worker.id_worker) = 1);
END;

