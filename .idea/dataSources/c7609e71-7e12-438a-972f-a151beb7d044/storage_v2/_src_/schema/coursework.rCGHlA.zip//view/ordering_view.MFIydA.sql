create view ordering_view as
select `coursework`.`ordering`.`id_ordering`    AS `id_ordering`,
       `coursework`.`ordering`.`General_Price`  AS `General_Price`,
       `coursework`.`ordering`.`Code_Ordering`  AS `Code_Ordering`,
       `coursework`.`ordering`.`Date_Ordering`  AS `Date_Ordering`,
       `coursework`.`ordering`.`Number_Service` AS `Number_Service`,
       `coursework`.`ordering`.`Client_id`      AS `Client_id`,
       `coursework`.`ordering`.`Worker_id`      AS `Worker_id`,
       `coursework`.`ordering`.`Kind_Service`   AS `Kind_Service`
from `coursework`.`ordering`;

