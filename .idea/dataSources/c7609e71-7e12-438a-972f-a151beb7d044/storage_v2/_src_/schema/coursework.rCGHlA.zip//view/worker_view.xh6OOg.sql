create view worker_view as
select `coursework`.`worker`.`id_worker`        AS `id_worker`,
       `coursework`.`worker`.`Name_Worker`      AS `Name_Worker`,
       `coursework`.`worker`.`Last_Name_Worker` AS `Last_Name_Worker`,
       `coursework`.`worker`.`Position`         AS `Position`
from `coursework`.`worker`;

