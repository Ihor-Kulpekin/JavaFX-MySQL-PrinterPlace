create
  definer = root@localhost procedure The_most_expensive_ordering_procedure()
BEGIN
Select client.Name_Client, client.Last_Name_Client, ordering.Kind_Service,
 max(ordering.General_Price)
 from client
Inner Join ordering On client.id_Client = ordering.Client_id;
END;

